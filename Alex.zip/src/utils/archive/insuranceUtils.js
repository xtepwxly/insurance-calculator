// utils/insuranceUtils.ts

import {
  PRODUCTS,
  ELIGIBILITY_OPTIONS,
  US_STATES,
  AGE_BANDED_RATES,
  LTD_CONFIG,
  STD_CONFIG,
  LIFE_ADD_CONFIG,
  ACCIDENT_PREMIUMS,
  VISION_PREMIUMS,
  DENTAL_PREMIUMS,
  ZIP_CODE_REGIONS,
  STATE_CATEGORIES
} from './insuranceConfig';
import { Product, EligibilityOption, USState, Plan, LifeAddInfo, IndividualInfo } from './insuranceTypes';

const getAgeBandedRate = (age: number): number => {
  const band = AGE_BANDED_RATES.find(band => age >= band.minAge && age <= band.maxAge);
  return band ? band.rate : AGE_BANDED_RATES[AGE_BANDED_RATES.length - 1].rate;
};

const getZipCodeRegion = (zipCode: string): number => {
  const region = Object.entries(ZIP_CODE_REGIONS).find(([_, zips]) => 
    zips.some(zipPrefix => zipCode.startsWith(zipPrefix))
  );
  return region ? parseInt(region[0]) : 1; // Default to region 1 if not found
};

const getStateCategory = (state: USState): string => {
  return Object.keys(STATE_CATEGORIES).find(category => STATE_CATEGORIES[category].includes(state)) || 'Other';
};

type PremiumCalculation = {
  STD: (age: number, annualSalary: number) => number;
  LTD: (annualSalary: number, plan: Plan) => number;
  'Life / AD&D': (age: number, lifeAddInfo: LifeAddInfo, eligibility: EligibilityOption) => number;
  Accidents: (plan: Plan, eligibility: EligibilityOption) => number;
  Dental: (plan: Plan, eligibility: EligibilityOption, zipCode: string) => number;
  Vision: (plan: Plan, eligibility: EligibilityOption, state: USState) => number;
  'Critical Illness/Cancer': () => number;
};

const PREMIUM_CALCULATIONS: PremiumCalculation = {
  STD: (age, annualSalary) => {
    const grossWeeklyIncome = annualSalary / 52;
    const grossWeeklyBenefitAmount = Math.min(grossWeeklyIncome * STD_CONFIG.benefitPercentage, STD_CONFIG.maxWeeklyBenefit);
    const units = Math.min(grossWeeklyBenefitAmount / 10, STD_CONFIG.maxUnits);
    return units * getAgeBandedRate(age);
  },

  LTD: (annualSalary, plan) => {
    const grossMonthlyIncome = annualSalary / 12;
    const { maxBenefit, costPerHundred } = LTD_CONFIG[plan];
    const units = Math.min(grossMonthlyIncome / 100, maxBenefit / 100);
    return units * costPerHundred;
  },

  'Life / AD&D': (age, { employeeElectedCoverage, spouseElectedCoverage, numberOfChildren }, eligibility) => {
    const ageFactor = age / 100;
    let totalCoverage = employeeElectedCoverage;
    if (eligibility.includes('Spouse')) totalCoverage += spouseElectedCoverage;
    if (eligibility.includes('Children')) totalCoverage += numberOfChildren * LIFE_ADD_CONFIG.childCoverage;
    return (totalCoverage / 1000) * LIFE_ADD_CONFIG.baseRate * (1 + ageFactor);
  },

  Accidents: (plan, eligibility) => ACCIDENT_PREMIUMS[plan][eligibility],

  Dental: (plan, eligibility, zipCode) => {
    const region = getZipCodeRegion(zipCode);
    return DENTAL_PREMIUMS[plan][region][eligibility];
  },

  Vision: (plan, eligibility, state) => {
    const stateCategory = getStateCategory(state);
    return VISION_PREMIUMS[stateCategory][plan][eligibility];
  },

  'Critical Illness/Cancer': () => 0 // Placeholder
};

export const calculatePremiums = (
  individualInfo: IndividualInfo,
  plan: Plan,
  lifeAddInfo: LifeAddInfo,
  productEligibility: Record<Product, EligibilityOption>,
  selectedProduct: Product
): Record<Product, number> => {
  const { age, annualSalary, zipCode, state } = individualInfo;
  const calculatePremium = PREMIUM_CALCULATIONS[selectedProduct];
  
  if (!calculatePremium) return { [selectedProduct]: 0 };

  const premium = calculatePremium(
    age, 
    annualSalary, 
    plan, 
    lifeAddInfo, 
    productEligibility[selectedProduct],
    zipCode,
    state
  );

  return { [selectedProduct]: premium };
};

export { PRODUCTS, ELIGIBILITY_OPTIONS, US_STATES };