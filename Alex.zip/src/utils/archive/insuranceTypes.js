// utils/insuranceTypes.ts

export type Product = 'LTD' | 'STD' | 'Life / AD&D' | 'Accidents' | 'Dental' | 'Vision' | 'Critical Illness/Cancer';

export type EligibilityOption = 'Individual' | 'Individual + Spouse' | 'Individual + Children' | 'Family';

export type USState = 'AL' | 'AK' | 'AZ' | /* ... all other states ... */ | 'WY';

export type Plan = 'Basic' | 'Premium';

export interface LifeAddInfo {
  employeeElectedCoverage: number;
  spouseElectedCoverage: number;
  numberOfChildren: number;
}

export interface IndividualInfo {
  age: number;
  annualSalary: number;
  zipCode: string;
  state: USState;
}

export interface PremiumResult {
  [key: string]: number;
}